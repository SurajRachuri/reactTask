export function Contact() {
  return (
    <section className="section">
      <h2>Contact</h2>
      <p>Email: suraj@example.com</p>
      <p>Phone: +91 9XXXXXXXXX</p>
    </section>
  );
}
