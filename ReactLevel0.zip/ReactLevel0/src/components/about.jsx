export function About() {
  return (
    <section className="section">
      <h2>About Me</h2>
      <p>
        I am a passionate React developer learning component-based UI
        development and building modern web applications.
      </p>
    </section>
  );
}
