function Appa(){

    return (
        <>
        <h1>Task 0.1</h1>
        <p>Hello world</p>
        </>
    )
}
export default Appa