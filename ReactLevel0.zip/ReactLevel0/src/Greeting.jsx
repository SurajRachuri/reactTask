function Greeting(props) {
  return (
    <h2>Hello, {props.name} {props.data}!</h2>
  );
};
export default Greeting;